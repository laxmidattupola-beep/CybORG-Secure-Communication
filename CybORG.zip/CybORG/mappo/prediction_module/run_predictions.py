"""Run the predictor alongside CybORG and log each prediction vs actual red action."""
from __future__ import annotations
import argparse, csv
from pathlib import Path
import numpy as np
from CybORG.mappo.cyborg_env import CybORGMAPPOEnv
from CybORG.mappo.prediction_module.collect_data import attach_red_action_capture, get_action_name
from CybORG.mappo.prediction_module.predictor import AttackPredictor
from CybORG.mappo.prediction_module.common import observations_to_features


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=5)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--model", default="CybORG/mappo/prediction_module/models/attack_predictor.joblib")
    parser.add_argument("--output", default="CybORG/mappo/prediction_module/data/prediction_log.csv")
    parser.add_argument("--seed", type=int, default=900)
    args = parser.parse_args()
    predictor = AttackPredictor(args.model)
    env = CybORGMAPPOEnv(steps=args.steps)
    output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
    fields = ["episode_id", "step", "predicted_action", "score", "actual_action", "correct", "top_predictions"]
    correct_count = total = 0
    try:
        with output.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
            for episode in range(args.episodes):
                observations = env.reset(); captured = {"action": None}
                attach_red_action_capture(env, captured)
                rng = np.random.default_rng(args.seed + episode)
                for step in range(args.steps):
                    result = predictor.predict(observations)
                    captured["action"] = None
                    actions = {agent_id: int(rng.integers(0, env.action_dim)) for agent_id in env.agent_ids}
                    next_observations, _rewards, terminated, _info = env.step(actions)
                    actual = get_action_name(captured.get("action"))
                    if actual:
                        correct = result["predicted_action"] == actual
                        correct_count += int(correct); total += 1
                        writer.writerow({"episode_id": episode, "step": step,
                                         "predicted_action": result["predicted_action"],
                                         "score": result["score"], "actual_action": actual,
                                         "correct": correct, "top_predictions": str(result["top_predictions"])})
                        print(f"ep={episode + 1} step={step + 1}: predicted={result['predicted_action']} "
                              f"score={result['score']:.3f} actual={actual} correct={correct}")
                    observations = next_observations
                    if terminated: break
    finally:
        env.close()
    print(f"\nSaved prediction log: {output.resolve()}")
    print(f"Correct: {correct_count}/{total}; accuracy={correct_count / total:.4f}" if total else "No predictions were scored.")

if __name__ == "__main__":
    main()
