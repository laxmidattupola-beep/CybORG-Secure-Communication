"""Train and save a supervised next-red-action classifier."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupShuffleSplit
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, f1_score
from CybORG.mappo.prediction_module.common import feature_columns, FEATURE_VERSION


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="CybORG/mappo/prediction_module/data/attack_dataset.csv")
    parser.add_argument("--model", default="CybORG/mappo/prediction_module/models/attack_predictor.joblib")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}. Run collect_data.py first.")
    with data_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if len(rows) < 10:
        raise ValueError(f"Only {len(rows)} samples found; collect more episodes (at least 10 samples required).")
    labels = np.asarray([r["label"] for r in rows], dtype=str)
    groups = np.asarray([r["episode_id"] for r in rows], dtype=str)
    X = np.asarray([[float(r[c]) for c in feature_columns()] for r in rows], dtype=np.float32)
    if X.shape[1] != 768 or not np.isfinite(X).all():
        raise ValueError(f"Invalid features: expected finite (N, 768), got {X.shape}")
    if len(np.unique(groups)) < 2:
        raise ValueError("Dataset must contain at least two distinct episodes for episode-wise splitting.")

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=args.seed)
    train_idx, test_idx = next(splitter.split(X, labels, groups))
    if len(np.unique(labels[train_idx])) < 1 or len(test_idx) == 0:
        raise ValueError("Episode-wise train/test split produced an empty partition.")
    model = RandomForestClassifier(n_estimators=250, class_weight="balanced_subsample",
                                   random_state=args.seed, n_jobs=-1, min_samples_leaf=2)
    model.fit(X[train_idx], labels[train_idx])
    pred = model.predict(X[test_idx])
    baseline = DummyClassifier(strategy="most_frequent").fit(X[train_idx], labels[train_idx])
    baseline_pred = baseline.predict(X[test_idx])

    model_path = Path(args.model)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"model": model, "feature_version": FEATURE_VERSION, "feature_count": 768,
               "classes": model.classes_.tolist(), "seed": args.seed}
    joblib.dump(payload, model_path)
    split_path = model_path.with_name("prediction_split.json")
    split = {"train_episode_ids": sorted(set(groups[train_idx].tolist())),
             "test_episode_ids": sorted(set(groups[test_idx].tolist())),
             "train_rows": int(len(train_idx)), "test_rows": int(len(test_idx)),
             "test_labels": labels[test_idx].tolist(), "test_predictions": pred.tolist(),
             "baseline_predictions": baseline_pred.tolist(),
             "model_accuracy": float(accuracy_score(labels[test_idx], pred)),
             "baseline_accuracy": float(accuracy_score(labels[test_idx], baseline_pred)),
             "model_macro_f1": float(f1_score(labels[test_idx], pred, average="macro", zero_division=0)),
             "class_distribution": {str(k): int(v) for k, v in zip(*np.unique(labels, return_counts=True))}}
    split_path.write_text(json.dumps(split, indent=2), encoding="utf-8")
    print(f"Saved model: {model_path.resolve()}")
    print(f"Episode-wise split: train={len(train_idx)} rows, test={len(test_idx)} rows")
    print(f"Held-out accuracy: {split['model_accuracy']:.4f}")
    print(f"Majority baseline accuracy: {split['baseline_accuracy']:.4f}")
    print(f"Held-out macro F1: {split['model_macro_f1']:.4f}")
    print(f"Split report: {split_path.resolve()}")

if __name__ == "__main__":
    main()
