"""Standalone next-red-agent-action prediction module for the CybORG project."""
