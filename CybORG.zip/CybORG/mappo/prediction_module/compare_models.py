﻿import pandas as pd

from pathlib import Path
from sklearn.model_selection import GroupShuffleSplit
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report


# --------------------------------------------------
# 1. Locate and load the existing dataset
# --------------------------------------------------

BASE_DIR = Path("CybORG/mappo/prediction_module")
DATASET_PATH = BASE_DIR / "data" / "attack_dataset.csv"

if not DATASET_PATH.exists():
    raise FileNotFoundError(
        f"Dataset not found: {DATASET_PATH.resolve()}"
    )

df = pd.read_csv(DATASET_PATH)

print("=" * 65)
print("CYBORG ATTACK PREDICTION: MODEL COMPARISON")
print("=" * 65)

print(f"\nDataset rows: {len(df)}")
print(f"Unique episodes: {df['episode_id'].nunique()}")
print(f"Attack-action classes: {df['label'].nunique()}")


# --------------------------------------------------
# 2. Separate features, labels and episode groups
# --------------------------------------------------

feature_cols = [
    col for col in df.columns
    if col.startswith("feature_")
]

feature_cols.sort(key=lambda col: int(col.split("_")[1]))

X = df[feature_cols].astype(float)
y = df["label"].astype(str)
groups = df["episode_id"]

print(f"Number of features: {len(feature_cols)}")

if len(feature_cols) != 768:
    raise ValueError(
        f"Expected 768 features, but found {len(feature_cols)}"
    )


# --------------------------------------------------
# 3. Create the same type of episode-based split
# --------------------------------------------------

splitter = GroupShuffleSplit(
    n_splits=1,
    test_size=0.25,
    random_state=42
)

train_idx, test_idx = next(
    splitter.split(X, y, groups=groups)
)

X_train = X.iloc[train_idx]
X_test = X.iloc[test_idx]

y_train = y.iloc[train_idx]
y_test = y.iloc[test_idx]

train_episodes = set(groups.iloc[train_idx])
test_episodes = set(groups.iloc[test_idx])

print(f"\nTraining rows: {len(X_train)}")
print(f"Testing rows: {len(X_test)}")
print(f"Training episodes: {len(train_episodes)}")
print(f"Testing episodes: {len(test_episodes)}")

if train_episodes.intersection(test_episodes):
    raise ValueError("Data leakage: an episode appears in both splits!")

print("\nTraining and testing episodes do not overlap.")


# --------------------------------------------------
# 4. Define the models
# --------------------------------------------------

models = {
    "Majority Baseline": DummyClassifier(
        strategy="most_frequent"
    ),

    "Random Forest": RandomForestClassifier(
        n_estimators=250,
        class_weight="balanced_subsample",
        random_state=42,
        n_jobs=-1,
        min_samples_leaf=2
    ),

    "Extra Trees": ExtraTreesClassifier(
        n_estimators=250,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
        min_samples_leaf=2
    )
}


# --------------------------------------------------
# 5. Train and evaluate each model
# --------------------------------------------------

results = []

for name, model in models.items():

    print("\n" + "-" * 65)
    print(f"Training: {name}")
    print("-" * 65)

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    macro_f1 = f1_score(
        y_test,
        predictions,
        average="macro",
        zero_division=0
    )
    weighted_f1 = f1_score(
        y_test,
        predictions,
        average="weighted",
        zero_division=0
    )

    results.append({
        "Model": name,
        "Accuracy": accuracy,
        "Macro F1": macro_f1,
        "Weighted F1": weighted_f1
    })

    print(f"Accuracy:   {accuracy:.4f}")
    print(f"Macro F1:   {macro_f1:.4f}")
    print(f"Weighted F1: {weighted_f1:.4f}")

    print("\nClassification report:")
    print(
        classification_report(
            y_test,
            predictions,
            zero_division=0
        )
    )


# --------------------------------------------------
# 6. Compare the final results
# --------------------------------------------------

results_df = pd.DataFrame(results)

print("\n" + "=" * 65)
print("FINAL MODEL COMPARISON")
print("=" * 65)

print(
    results_df.sort_values(
        by="Macro F1",
        ascending=False
    ).to_string(
        index=False,
        formatters={
            "Accuracy": "{:.4f}".format,
            "Macro F1": "{:.4f}".format,
            "Weighted F1": "{:.4f}".format
        }
    )
)

output_path = BASE_DIR / "models" / "model_comparison.csv"
output_path.parent.mkdir(parents=True, exist_ok=True)

results_df.to_csv(output_path, index=False)

print(f"\nResults saved to: {output_path}")
print("\nComparison completed.")
