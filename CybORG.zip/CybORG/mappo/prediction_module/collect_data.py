"""Collect supervised next-red-action examples from the real CybORG wrapper.

Run from the repository root:
  python -m CybORG.mappo.prediction_module.collect_data --episodes 40 --steps 100
"""
from __future__ import annotations
import argparse
import csv
import json
import random
from pathlib import Path
import numpy as np
from CybORG.mappo.cyborg_env import CybORGMAPPOEnv
from CybORG.mappo.prediction_module.common import observations_to_features, feature_columns, FEATURE_VERSION


def get_action_name(action):
    if action is None:
        return None
    # CybORG actions are normally action objects; class name is the stable label.
    return type(action).__name__


def attach_red_action_capture(env, captured):
    """Wrap the real red agent's get_action method without changing its behavior."""
    interfaces = env.env.environment_controller.agent_interfaces
    red_items = [(agent_id, interface) for agent_id, interface in interfaces.items()
                 if agent_id.lower().startswith("red_agent")]
    if not red_items:
        # Fall back to the actual agent class, avoiding assumptions about IDs.
        red_items = [(agent_id, interface) for agent_id, interface in interfaces.items()
                     if "FiniteStateRedAgent" in type(interface.agent).__name__]
    if not red_items:
        raise RuntimeError("Could not find the red agent in environment_controller.agent_interfaces")
    agent_id, interface = red_items[0]
    agent = interface.agent
    if getattr(agent, "_prediction_capture_installed", False):
        agent._prediction_capture = captured
        return agent_id
    original = agent.get_action
    def wrapped_get_action(observation, action_space, *args, **kwargs):
        action = original(observation, action_space, *args, **kwargs)
        active_capture = getattr(agent, "_prediction_capture", None)
        if active_capture is not None:
            active_capture["action"] = action
        return action
    agent.get_action = wrapped_get_action
    agent._prediction_capture_installed = True
    agent._prediction_capture = captured
    return agent_id


def main():
    parser = argparse.ArgumentParser(description="Collect CybORG red-agent next-action data")
    parser.add_argument("--episodes", type=int, default=40)
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="CybORG/mappo/prediction_module/data/attack_dataset.csv")
    args = parser.parse_args()
    if args.episodes < 2 or args.steps < 2:
        parser.error("Use at least 2 episodes and 2 steps")

    random.seed(args.seed)
    np.random.seed(args.seed)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    columns = ["episode_id", "step", "label"] + feature_columns()
    rows = []
    env = CybORGMAPPOEnv(steps=args.steps)
    try:
        for episode in range(args.episodes):
            observations = env.reset()
            captured = {"action": None}
            attach_red_action_capture(env, captured)
            rng = np.random.default_rng(args.seed + episode)
            episode_rows = 0
            for step in range(args.steps):
                # Record only information available before the next environment step.
                features = observations_to_features(observations)
                captured["action"] = None
                # Random valid-index choices avoid relying on a checkpoint whose
                # encoder compatibility has not been established. 0..7 are the
                # wrapper's actual high-level blue action indices.
                actions = {agent_id: int(rng.integers(0, env.action_dim)) for agent_id in env.agent_ids}
                next_observations, _rewards, terminated, _info = env.step(actions)
                label = get_action_name(captured.get("action"))
                if label:
                    row = {"episode_id": episode, "step": step, "label": label}
                    row.update({name: float(value) for name, value in zip(feature_columns(), features)})
                    rows.append(row)
                    episode_rows += 1
                observations = next_observations
                if terminated:
                    break
            print(f"Episode {episode + 1}/{args.episodes}: recorded {episode_rows} labelled steps")
    finally:
        env.close()

    if not rows:
        raise RuntimeError("No red-agent actions were captured. Check the red agent interface and CybORG runtime.")
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    metadata = {"rows": len(rows), "episodes_requested": args.episodes, "steps_per_episode": args.steps,
                "feature_version": FEATURE_VERSION, "feature_count": 768,
                "label_counts": {k: sum(r["label"] == k for r in rows) for k in sorted({r["label"] for r in rows})},
                "blue_policy": "random high-level actions; MAPPO checkpoint not required"}
    output.with_suffix(".metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"\nSaved dataset: {output.resolve()}")
    print(f"Samples: {len(rows)} | Classes: {len(metadata['label_counts'])}")
    print("Note: labels are the actual returned red-agent action class names captured during CybORG steps.")

if __name__ == "__main__":
    main()
