"""Shared feature preparation for collecting and serving attack predictions."""
from __future__ import annotations
import numpy as np

FEATURE_VERSION = "blue_obs_mean_max_std_v1"


def observations_to_features(observations: dict) -> np.ndarray:
    """Convert the five blue-agent 256-D observations into one 768-D vector.

    Uses only defender-visible observations: mean, max and standard deviation
    across blue agents. Does not read hidden CybORG simulator state.
    """
    if not isinstance(observations, dict) or not observations:
        raise ValueError("observations must be a non-empty agent->vector dictionary")
    arrays = []
    for agent_id in sorted(observations):
        arr = np.asarray(observations[agent_id], dtype=np.float32).reshape(-1)
        if arr.size != 256:
            raise ValueError(f"Expected 256 features for {agent_id}, got {arr.size}")
        if not np.isfinite(arr).all():
            arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
        arrays.append(arr)
    stacked = np.stack(arrays, axis=0)
    return np.concatenate((stacked.mean(axis=0), stacked.max(axis=0), stacked.std(axis=0))).astype(np.float32)


def feature_columns():
    return [f"feature_{i}" for i in range(768)]
