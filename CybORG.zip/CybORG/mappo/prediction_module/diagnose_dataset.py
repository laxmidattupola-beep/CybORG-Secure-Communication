﻿import pandas as pd
import numpy as np
from pathlib import Path

DATASET_PATH = Path(
    "CybORG/mappo/prediction_module/data/attack_dataset.csv"
)

df = pd.read_csv(DATASET_PATH)

feature_cols = [
    c for c in df.columns if c.startswith("feature_")
]
feature_cols.sort(key=lambda c: int(c.split("_")[1]))

print("=" * 70)
print("CYBORG DATASET DIAGNOSTICS")
print("=" * 70)

# 1. Basic dataset information
print("\n1. DATASET INFORMATION")
print("Total rows:", len(df))
print("Unique episodes:", df["episode_id"].nunique())
print("Number of features:", len(feature_cols))
print("Number of action classes:", df["label"].nunique())

# 2. Overall class distribution
print("\n2. ACTION COUNTS")
print(df["label"].value_counts().to_string())

print("\nAction percentages:")
print(
    (df["label"].value_counts(normalize=True) * 100)
    .round(2)
    .to_string()
)

# 3. Class distribution in each episode
print("\n3. ACTION COUNTS PER EPISODE")
episode_counts = pd.crosstab(df["episode_id"], df["label"])
print(episode_counts.to_string())

# 4. Check missing and invalid feature values
print("\n4. FEATURE QUALITY")
X = df[feature_cols].apply(pd.to_numeric, errors="coerce")

print("Missing feature values:", int(X.isna().sum().sum()))
print("Infinite feature values:", int(np.isinf(X.to_numpy()).sum()))

constant_features = [
    c for c in feature_cols
    if X[c].nunique(dropna=False) <= 1
]

print("Constant features:", len(constant_features))

# 5. Check feature variation
feature_std = X.std(axis=0)

print("\n5. FEATURE VARIATION")
print("Features with zero standard deviation:",
      int((feature_std.fillna(0) == 0).sum()))
print("Median feature standard deviation:",
      round(float(feature_std.median()), 6))
print("Maximum feature standard deviation:",
      round(float(feature_std.max()), 6))

# 6. Check duplicate feature vectors
duplicate_features = X.duplicated(keep=False)

print("\n6. DUPLICATE FEATURE VECTORS")
print("Rows belonging to duplicated feature vectors:",
      int(duplicate_features.sum()))

if duplicate_features.any():
    duplicate_df = df.loc[duplicate_features, ["episode_id", "label"]]
    print("Different labels among duplicate vectors:")
    print(
        duplicate_df.groupby(
            [df.loc[duplicate_features].index, "label"]
        ).size().head(10).to_string()
    )

# 7. Check how often the attack action changes within an episode
print("\n7. ACTION CHANGES OVER TIME")

if "step" in df.columns:
    ordered = df.sort_values(["episode_id", "step"])
else:
    ordered = df.sort_values(["episode_id"])

previous_label = ordered.groupby("episode_id")["label"].shift(1)

valid = previous_label.notna()
changes = (
    ordered.loc[valid, "label"].to_numpy()
    != previous_label.loc[valid].to_numpy()
)

if len(changes):
    print("Adjacent action pairs:", len(changes))
    print("Action changes:", int(changes.sum()))
    print("Action change percentage:",
          round(float(changes.mean() * 100), 2), "%")
else:
    print("Not enough rows to calculate action changes.")

# 8. Check whether the same feature vector has conflicting labels
check = X.copy()
check["_label"] = df["label"].to_numpy()

label_counts = check.groupby(feature_cols, dropna=False)["_label"].nunique()
conflicting_vectors = int((label_counts > 1).sum())

print("\n8. FEATURE/LABEL AMBIGUITY")
print("Unique feature vectors with multiple labels:",
      conflicting_vectors)

print("\nDiagnostics completed.")
