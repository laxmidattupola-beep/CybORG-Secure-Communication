"""Load a trained predictor and predict from defender-visible observations."""
from __future__ import annotations
from pathlib import Path
import joblib
import numpy as np
from CybORG.mappo.prediction_module.common import observations_to_features, FEATURE_VERSION


class AttackPredictor:
    def __init__(self, model_path="CybORG/mappo/prediction_module/models/attack_predictor.joblib"):
        path = Path(model_path)
        if not path.exists():
            raise FileNotFoundError(f"Prediction model not found: {path}. Collect data and train first.")
        payload = joblib.load(path)
        if payload.get("feature_version") != FEATURE_VERSION or payload.get("feature_count") != 768:
            raise ValueError("Prediction model feature schema does not match the current observation encoder.")
        self.model = payload["model"]

    def predict(self, observations, top_k=3):
        """Return the most likely next red action and its model score.

        Scores are classifier probabilities, not guaranteed calibrated confidence.
        """
        features = observations_to_features(observations).reshape(1, -1)
        probabilities = self.model.predict_proba(features)[0]
        order = np.argsort(probabilities)[::-1][:max(1, min(int(top_k), len(probabilities)))]
        ranked = [{"action": str(self.model.classes_[i]), "score": float(probabilities[i])} for i in order]
        return {"predicted_action": ranked[0]["action"], "score": ranked[0]["score"], "top_predictions": ranked}
