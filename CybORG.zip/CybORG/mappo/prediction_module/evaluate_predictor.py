"""Detailed evaluation on the held-out episodes selected during training."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", default="CybORG/mappo/prediction_module/models/prediction_split.json")
    args = parser.parse_args()
    path = Path(args.split)
    if not path.exists():
        raise FileNotFoundError(f"Split report not found: {path}. Train the predictor first.")
    data = json.loads(path.read_text(encoding="utf-8"))
    y_true = np.asarray(data["test_labels"], dtype=str)
    y_pred = np.asarray(data["test_predictions"], dtype=str)
    classes = sorted(set(y_true.tolist()) | set(y_pred.tolist()))
    print(f"Held-out samples: {len(y_true)}")
    print(f"Held-out episodes: {len(data['test_episode_ids'])}")
    print(f"Model accuracy: {data['model_accuracy']:.4f}")
    print(f"Majority baseline accuracy: {data['baseline_accuracy']:.4f}")
    print(f"Macro F1: {data['model_macro_f1']:.4f}\n")
    print("Classification report:")
    print(classification_report(y_true, y_pred, labels=classes, zero_division=0))
    print("Confusion matrix (class order below):")
    print(classes)
    print(confusion_matrix(y_true, y_pred, labels=classes))
    print("\nClass distribution:")
    print(json.dumps(data["class_distribution"], indent=2))
    print("\nInterpretation: these results apply to this CybORG scenario and collected episodes only.")

if __name__ == "__main__":
    main()
