# CybORG next-red-action Prediction Module

This module predicts the next action class returned by the project's actual `FiniteStateRedAgent`. It runs separately from MAPPO and does not modify MAPPO checkpoints or policies.

## Run from the repository root (Python 3.10)

Install only the extra ML dependencies if they are missing:

```powershell
py -3.10 -m pip install scikit-learn joblib
```

Collect labelled simulation data (this uses random high-level blue actions, so no MAPPO checkpoint is assumed compatible):

```powershell
py -3.10 -m CybORG.mappo.prediction_module.collect_data --episodes 40 --steps 100
```

Train the predictor; the split is grouped by episode to avoid putting steps from one episode in both sets:

```powershell
py -3.10 -m CybORG.mappo.prediction_module.train_predictor
```

Print detailed held-out metrics:

```powershell
py -3.10 -m CybORG.mappo.prediction_module.evaluate_predictor
```

Run the model alongside the environment and compare predictions with actual red-agent actions:

```powershell
py -3.10 -m CybORG.mappo.prediction_module.run_predictions --episodes 5 --steps 100
```

## Output files

- `data/attack_dataset.csv`: features and actual action labels.
- `data/attack_dataset.metadata.json`: dataset size and class counts.
- `models/attack_predictor.joblib`: trained classifier and feature schema.
- `models/prediction_split.json`: held-out predictions, split episode IDs and summary metrics.
- `data/prediction_log.csv`: per-step live comparison log.

## Important limitations

- Prediction target is the next action **class**, not a host/target or full future sequence.
- Inputs are aggregated defender-visible observations (mean, max, standard deviation across blue agents), 768 features total.
- The collector captures the action object returned by the real red agent. If this repository's runtime calls a different interface, the collector raises an explicit error or produces no rows rather than inventing labels.
- Initial data collection uses random blue actions because the repository warns that older MAPPO checkpoints may not match the current semantic observation encoder. This does not alter the existing MAPPO model.
- Classifier scores are not guaranteed to be calibrated probabilities.
- Evaluation is valid only for the simulated scenario and the collected episode distribution; it does not establish real-world attack prediction ability.
